"""dj-crate skill script (Door 1): preview a crate from crates/<slug>.spec.yaml, or write its
rekordbox XML and crate record after the DJ's explicit yes. A thin wrapper around `dj.crate`.

    python crate.py preview <spec> [--library DIR] [--today YYYY-MM-DD]
    python crate.py apply <spec> --preview-id ID [--library DIR] [--today YYYY-MM-DD]

<spec> = the crate's slug, or the path of crates/<slug>.spec.yaml in the library folder.
--library defaults to the configured dj-library folder. Prints one JSON object on stdout.
Exit 0 = done, 1 = error, 2 = refused (no valid preview id: preview again, ask again).
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path
from typing import Any, NoReturn

try:  # the dj core, in this order (D-29): importable (engine venv or PyPI), a clone, the plugin zip
    import dj  # noqa: F401
except ImportError:  # a clone of the repo keeps it in ../../../../src, the plugin zip in ../../../engine/src
    _here = Path(__file__).resolve().parent
    for _core in (_here / "../../../../src", _here / "../../../engine/src"):
        if (_core / "dj" / "__init__.py").is_file():
            sys.path.insert(0, str(_core.resolve()))
            break

EXIT_OK, EXIT_ERROR, EXIT_REFUSED = 0, 1, 2


def emit(data: dict[str, Any], code: int) -> NoReturn:
    sys.stdout.write(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    sys.stdout.flush()
    raise SystemExit(code)


class Parser(argparse.ArgumentParser):
    """Usage errors are errors (exit 1, JSON), not argparse's exit 2 (which means refused here)."""

    def error(self, message: str) -> NoReturn:
        emit({"ok": False, "error": message}, EXIT_ERROR)


def parse(argv: list[str] | None) -> argparse.Namespace:
    parser = Parser(prog="crate.py", description="Preview a crate, or write its XML after a yes.")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("preview", "apply"):
        cmd = sub.add_parser(name)
        cmd.add_argument("spec", help="the crate's slug, or the path of crates/<slug>.spec.yaml")
        cmd.add_argument("--library", help="the dj-library folder (default: the configured one)")
        cmd.add_argument("--today", help="date written into crates/<slug>.md, YYYY-MM-DD")
        if name == "apply":
            cmd.add_argument("--preview-id", default="", help="the id the preview returned")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> NoReturn:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    args = parse(argv)
    if args.command == "apply" and not args.preview_id.strip():
        emit({"ok": False, "refused": "No preview id: run the preview, show it, write only after a yes."},
             EXIT_REFUSED)  # fmt: skip

    try:
        from dj import crate, libfolder
        from dj.gate import GateError
        from dj.model import LibraryError
        from dj.writers.rekordbox_xml import BuildError
    except ImportError as exc:  # no engine venv and not inside a clone of the repo (Q-06)
        emit({"ok": False, "error": f"cannot load the dj-librarian core: {exc}", "reason": "core"}, EXIT_ERROR)

    try:
        today = date.fromisoformat(args.today) if args.today else None
    except ValueError:
        emit({"ok": False, "error": f"--today: expected YYYY-MM-DD, got {args.today!r}"}, EXIT_ERROR)
    try:
        root = Path(args.library) if args.library else libfolder.configured_root()
        if not root.is_dir():
            emit({"ok": False, "error": f"{root} is not a folder. Run dj-start first."}, EXIT_ERROR)
        if args.command == "preview":
            data = crate.preview(root, args.spec, today=today).to_dict()
        else:
            data = crate.apply(root, args.spec, args.preview_id.strip(), today=today).to_dict()
    except GateError as exc:
        emit({"ok": False, "refused": str(exc)}, EXIT_REFUSED)
    except (crate.CrateError, BuildError, LibraryError, OSError) as exc:
        emit({"ok": False, "error": str(exc)}, EXIT_ERROR)
    emit({"ok": True, **data}, EXIT_OK)


if __name__ == "__main__":
    main()
